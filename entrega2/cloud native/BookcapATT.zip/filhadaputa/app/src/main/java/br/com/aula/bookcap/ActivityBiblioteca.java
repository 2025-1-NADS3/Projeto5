package br.com.aula.bookcap;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;

public class ActivityBiblioteca extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_biblioteca);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        adicionarClick(R.id.livro1, "O Menino do Pijama Listrado", "Conta a amizade entre Bruno, filho de um oficial nazista, e Shmuel, um prisioneiro judeu.", R.drawable.menino_do_pijama_listrado);
        adicionarClick(R.id.livro2, "Entendendo Algoritmos ", "Um guia ilustrado para programadores e outros curiosos. Um algoritmo nada mais é do que um procedimento passo a passo para a resolução de um problema.", R.drawable.entendendo_algoritimos);
        adicionarClick(R.id.livro3, "Inteligência artificial na sala de aula", "Qual é o impacto da Inteligência Artificial na educação? O que um professor precisa saber para lidar com esses novos tempos?", R.drawable.inteligencia_artificial);
        adicionarClick(R.id.livro4, "Futuro Presente", "Inteligência Artificial, Robótica, Internet das Coisas, Nanotecnologia, Biotecnologia, Veículos Autônomos, Impressão 3D, Realidade Virtual...", R.drawable.futuro_presente);
        adicionarClick(R.id.livro5, "Programador Autodidata", "Este livro não é apenas sobre aprender a programar. É sobre todas as outras coisas que você precisa saber que as aulas e os livros não ensinam.", R.drawable.programador_autodidata);
        adicionarClick(R.id.livro6, "Introdução à Programação com Python", "Este livro se destina ao iniciante em programação e foi escrito para ajudar o leitor autodidata a aprender a programar.", R.drawable.python);
        adicionarClick(R.id.livro7, "Use a Cabeça Java", "O “Use a Cabeça Java” é uma experiência completa de aprendizado em Java e programação orientada a objetos. ", R.drawable.java);
        adicionarClick(R.id.livro8, "Introdução à Linguagem SQL", "Atualmente as empresas estão coletando dados a taxas exponenciais e mesmo assim poucas pessoas sabem como acessá-los de maneira relevante.", R.drawable.sql_image);
        adicionarClick(R.id.livro9, "O Codificador Limpo", "Então você quer ser um profissional do desenvolvimento de softwares. Quer erguer a cabeça e declarar para o mundo: “Eu sou um profissional!”.", R.drawable.codificador_limpo);
    }

    private void adicionarClick(int viewId, String titulo, String descricao, int capaResId) {
        LinearLayout livro = findViewById(viewId);
        livro.setOnClickListener(v -> {
            Intent intent = new Intent(ActivityBiblioteca.this, ActivityLivroDetalhe.class);
            intent.putExtra("titulo", titulo);
            intent.putExtra("descricao", descricao);
            intent.putExtra("capa", capaResId);
            startActivity(intent);
        });
    }
}
