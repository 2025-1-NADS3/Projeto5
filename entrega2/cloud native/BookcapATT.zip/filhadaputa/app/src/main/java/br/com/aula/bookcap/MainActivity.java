package br.com.aula.bookcap;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class MainActivity extends AppCompatActivity {

    EditText edtUsuario, edtSenha;
    Button btnCadastrar;
    ImageButton botaoModo;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtUsuario = findViewById(R.id.edtUsuario);
        edtSenha = findViewById(R.id.edtSenha);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        botaoModo = findViewById(R.id.botaoModo);

        db = new DatabaseHelper(this);

        btnCadastrar.setOnClickListener(v -> {
            String usuario = edtUsuario.getText().toString();
            String senha = edtSenha.getText().toString();

            if (usuario.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean sucesso = db.cadastrarUsuario(usuario, senha);
            if (sucesso) {
                Toast.makeText(this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Usuário já existe!", Toast.LENGTH_SHORT).show();
            }
        });

        // Lógica para mudar entre modo claro e escuro
        botaoModo.setOnClickListener(view -> {
            int modoAtual = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;

            if (modoAtual == android.content.res.Configuration.UI_MODE_NIGHT_YES) {
                // Está no modo escuro, mudar para claro
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                botaoModo.setImageResource(R.drawable.ic_modo_claro);
            } else {
                // Está no modo claro, mudar para escuro
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                botaoModo.setImageResource(R.drawable.ic_modo_escuro);
            }
        });
    }
}
