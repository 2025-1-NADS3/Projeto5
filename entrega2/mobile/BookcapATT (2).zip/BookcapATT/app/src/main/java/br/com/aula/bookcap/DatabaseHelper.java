package br.com.aula.bookcap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.security.MessageDigest;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "UsuariosDB.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "usuarios";
    private static final String COL_ID = "id";
    private static final String COL_USUARIO = "usuario";
    private static final String COL_SENHA = "senha";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Criar a tabela
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USUARIO + " TEXT, " +
                COL_SENHA + " TEXT)";
        db.execSQL(createTable);
    }

    // Atualizar banco se necessário
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Criptografar senha (hash SHA-256)
    private String criptografarSenha(String senha) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(senha.getBytes("UTF-8"));
            return Base64.encodeToString(hash, Base64.DEFAULT).trim();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Cadastrar novo usuário
    public boolean cadastrarUsuario(String usuario, String senha) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Criptografa a senha
        String senhaCriptografada = criptografarSenha(senha);

        // Verifica se o usuário já existe
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COL_USUARIO + " = ?", new String[]{usuario});
        if (cursor.getCount() > 0) {
            cursor.close();
            return false; // já existe
        }

        ContentValues values = new ContentValues();
        values.put(COL_USUARIO, usuario);
        values.put(COL_SENHA, senhaCriptografada);

        long result = db.insert(TABLE_NAME, null, values);
        cursor.close();
        return result != -1;
    }

    // Verifica login
    public boolean login(String usuario, String senha) {
        SQLiteDatabase db = this.getReadableDatabase();
        String senhaCriptografada = criptografarSenha(senha);
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " +
                COL_USUARIO + " = ? AND " + COL_SENHA + " = ?", new String[]{usuario, senhaCriptografada});
        boolean resultado = cursor.getCount() > 0;
        cursor.close();
        return resultado;
    }
}
